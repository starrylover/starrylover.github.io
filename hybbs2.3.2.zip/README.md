# HYBBS2
基于HYPHP MVC框架开发的PHP论坛程序，拥有插件、模板扩展。

如果需要下载正式版 请到https://github.com/hyyyp/HYBBS2/releases 下载
