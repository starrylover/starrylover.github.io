<?php !defined('HY_PATH') && exit('HY_PATH not defined.'); ?>
{include header}
<div class="container" style="margin-top: 23px;">
	<div class="wrap-box">
	<!--{hook t_post_edit_1}-->
	<!--{hook t_post_edit}-->
	</div>
	
{include footer}