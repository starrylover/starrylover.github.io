<?php
return array(
    'name' => 'HY-MEditor编辑器',
    'user' => 'admin',
    'icon' => '',
    'mess' => '移动端手机版发表帖子需要用到的富文本编辑器',
    'version' => '1.2',
);