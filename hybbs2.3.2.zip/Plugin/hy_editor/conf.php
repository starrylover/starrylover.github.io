<?php
return array(
    'name' => 'HY-Editor编辑器',
    'user' => 'admin',
    'icon' => '',
    'mess' => 'PC电脑版发表帖子需要用到的富文本编辑器',
    'version' => '1.2',
);